package com.SpringBoot.CrudDemoEmp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudDemoEmpApplicationTests {

	@Test
	void contextLoads() {
	}

}
