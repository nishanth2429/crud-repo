package com.SpringBoot.CrudDemoEmp.Rest;


import com.SpringBoot.CrudDemoEmp.Dao.EmployeeDao;
import com.SpringBoot.CrudDemoEmp.entity.Employee;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class EmployeeRestController {


    private EmployeeDao employeeDao;
    //inject employee dao
    public EmployeeRestController(EmployeeDao theEmployeeDao){
        this.employeeDao=theEmployeeDao;
    }



    //expose "/employee and return the lis of employees
    @GetMapping("/employee")
    public List<Employee>findAll(){
        return employeeDao.findAll();
    }



}
