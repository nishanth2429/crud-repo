package com.SpringBoot.CrudDemoEmp.Dao;

import com.SpringBoot.CrudDemoEmp.entity.Employee;

import java.util.List;

public interface EmployeeDao {
    List<Employee> findAll();

}
