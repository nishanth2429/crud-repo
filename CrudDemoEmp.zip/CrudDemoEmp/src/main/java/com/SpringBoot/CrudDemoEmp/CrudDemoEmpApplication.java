package com.SpringBoot.CrudDemoEmp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudDemoEmpApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudDemoEmpApplication.class, args);
	}

}
